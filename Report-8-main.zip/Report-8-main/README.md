**Ayurveda Term Extraction and Classification**


Extracts and classifies Ayurveda terms from a PDF into categories like Ingredients, Symptoms, Treatments, Diseases, and Medical Plants, and saves them in a CSV file.
